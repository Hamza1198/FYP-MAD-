import 'package:flutter/material.dart';
void main() {
  runApp(const MyApp());
}
class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'AI MRI',
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF0D1B2A),
      ),
      home: const Lab10Dashboard(),
    );
  }
}

class Lab10Dashboard extends StatelessWidget {
  const Lab10Dashboard({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // --- DRAWER (From Lab 9) ---
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            const UserAccountsDrawerHeader(
              decoration: BoxDecoration(color: Color(0xFF1B263B)),
              accountName: Text("Dr. XYZ"),
              accountEmail: Text("doctor@mindsync.ai"),
              currentAccountPicture: CircleAvatar(
                backgroundColor: Colors.white,
                child: Icon(Icons.person, color: Color(0xFF1B263B)),
              ),
            ),
            ListTile(
              leading: const Icon(Icons.dashboard),
              title: const Text("Dashboard"),
              onTap: () => Navigator.pop(context),
            ),
            const Divider(),
          ],
        ),
      ),

      // --- BODY (Lab 10: CustomScrollView with Slivers) ---
      body: CustomScrollView(
        slivers: <Widget>[
          // 1. SliverAppBar (Collapsing Effect)
          const SliverAppBar(
            expandedHeight: 200.0,
            floating: false,
            pinned: true,
            flexibleSpace: FlexibleSpaceBar(
              title: Text("MRI AI Analytics"),
              background: Image(
                image: NetworkImage('https://images.unsplash.com/photo-1530213786676-41ad9f7736f6?fit=crop&w=500&q=60'),
                fit: BoxFit.cover,
              ),
            ),
          ),

          // 2. SliverGrid (Displaying AI Results in Grid - Lab 10 Task)
          SliverPadding(
            padding: const EdgeInsets.all(15.0),
            sliver: SliverGrid(
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2, // 2 items per row
                mainAxisSpacing: 10.0,
                crossAxisSpacing: 10.0,
                childAspectRatio: 1.2,
              ),
              delegate: SliverChildBuilderDelegate(
                    (BuildContext context, int index) {
                  final labels = ['Tumor Detection', 'Scan Quality', 'Accuracy', 'AI Confidence'];
                  final icons = [Icons.biotech, Icons.high_quality, Icons.track_changes, Icons.auto_awesome];

                  // Returning Card with Column (Icon, Divider, Text) as per Lab 10 manual
                  return Card(
                    elevation: 5,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                    color: const Color(0xFF1B263B),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        Icon(icons[index % 4], size: 40, color: Colors.blueAccent),
                        const Divider(indent: 20, endIndent: 20, color: Colors.white24),
                        Text(
                          labels[index % 4],
                          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                        ),
                      ],
                    ),
                  );
                },
                childCount: 4, // Number of grid items
              ),
            ),
          ),

          // 3. SliverList (Recent MRI Reports - Lab 10 Task)
          SliverList(
            delegate: SliverChildBuilderDelegate(
                  (BuildContext context, int index) {
                return Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 5),
                  child: Card(
                    child: ListTile(
                      leading: const CircleAvatar(
                        backgroundColor: Colors.blueAccent,
                        child: Icon(Icons.description, color: Colors.white),
                      ),
                      title: Text("Patient MRI Report #${index + 101}"),
                      subtitle: Text("Analysis completed: April ${index + 1}, 2026"),
                      trailing: const Icon(Icons.arrow_forward_ios, size: 15),
                      onTap: () {},
                    ),
                  ),
                );
              },
              childCount: 8,
            ),
          ),
        ],
      ),
    );
  }
}