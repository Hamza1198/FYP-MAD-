 /*// page 1
import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: const SplashScreen(),
    );
  }
}

class SplashScreen extends StatelessWidget {
  const SplashScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFF1E3A8A),
              Color(0xFF1E40AF),
              Color(0xFF1E3A8A),
            ],
          ),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Logo
            Stack(
              alignment: Alignment.center,
              children: [
                // Purple Sphere
                Container(
                  width: 120,
                  height: 120,
                  decoration: const BoxDecoration(
                    shape: BoxShape.circle,
                    color: Color(0xFF4F46E5),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black26,
                        blurRadius: 20,
                        offset: Offset(0, 10),
                      ),
                    ],
                  ),
                ),
                // Red Arrow
                const Positioned(
                  top: 15,
                  child: Icon(
                    Icons.arrow_upward_rounded,
                    size: 80,
                    color: Color(0xFFEF4444),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 30),

            // Title
            const Text(
              'MRI MASTER',
              style: TextStyle(
                fontSize: 36,
                fontWeight: FontWeight.bold,
                color: Colors.white,
                letterSpacing: 2,
              ),
            ),
          ],
        ),
      ),
      bottomSheet: const Padding(
        padding: EdgeInsets.only(bottom: 40),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'Ver 1.0.0+1',
              style: TextStyle(color: Colors.white70, fontSize: 14),
            ),
            SizedBox(height: 8),
            Text(
              'Copyright © 2021 | MRIMASTER',
              style: TextStyle(color: Colors.white70, fontSize: 13),
            ),
            Text(
              'Designated trademarks, products are the',
              style: TextStyle(color: Colors.white70, fontSize: 13),
            ),
            Text(
              'property of MRI MASTER.',
              style: TextStyle(color: Colors.white70, fontSize: 13),
            ),
            Text(
              'All Rights Reserved.',
              style: TextStyle(color: Colors.white70, fontSize: 13),
            ),
          ],
        ),
      ),
    );
  }
}

// page 2
import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: const IndicationsScreen(),
    );
  }
}

class IndicationsScreen extends StatelessWidget {
  const IndicationsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF0A2540),
        leading: const Icon(Icons.arrow_back, color: Colors.white),
        title: const Text(
          "PLANNING > BRAIN",
          style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w500),
        ),
        actions: const [
          Padding(
            padding: EdgeInsets.only(right: 16),
            child: Icon(Icons.home, color: Colors.white),
          ),
        ],
      ),
      body: Column(
        children: [
          // MRI Images Strip
          Container(
            height: 90,
            width: double.infinity,
            color: Colors.black,
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  Image.asset('assets/mri1.jpg', height: 90, fit: BoxFit.cover),
                  Image.asset('assets/mri2.jpg', height: 90, fit: BoxFit.cover),
                  Image.asset('assets/mri3.jpg', height: 90, fit: BoxFit.cover),
                  Image.asset('assets/mri4.jpg', height: 90, fit: BoxFit.cover),
                  Image.asset('assets/mri5.jpg', height: 90, fit: BoxFit.cover),
                  Image.asset('assets/mri6.jpg', height: 90, fit: BoxFit.cover),
                ],
              ),
            ),
          ),

          // Title
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 20),
            color: Colors.white,
            child: const Text(
              "INDICATIONS FOR MRI HEART ",
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Color(0xFF0A2540),
              ),
            ),
          ),

          // List of Indications
          Expanded(
            child: Container(
              color: Colors.white,
              child: ListView(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                children: const [
                  ListTile(
                    leading: Text("1.", style: TextStyle(fontWeight: FontWeight.bold)),
                    title: Text("Transient ischaemic attack (TIA), cerebrovascular attack (CVA)"),
                    dense: true,
                  ),
                  ListTile(
                    leading: Text("2.", style: TextStyle(fontWeight: FontWeight.bold)),
                    title: Text("Infection, inflammation, meningitis, encephalitis, HIV, AIDS, TB"),
                    dense: true,
                  ),
                  ListTile(
                    leading: Text("3.", style: TextStyle(fontWeight: FontWeight.bold)),
                    title: Text("Cognitive decline, neurodegenerative disorders, dementia"),
                    dense: true,
                  ),
                  ListTile(
                    leading: Text("4.", style: TextStyle(fontWeight: FontWeight.bold)),
                    title: Text("Demyelinating disease, multiple sclerosis"),
                    dense: true,
                  ),
                  ListTile(
                    leading: Text("5.", style: TextStyle(fontWeight: FontWeight.bold)),
                    title: Text("Loss of consciousness, seizures, epilepsy"),
                    dense: true,
                  ),
                  ListTile(
                    leading: Text("6.", style: TextStyle(fontWeight: FontWeight.bold)),
                    title: Text("Brain tumour, metastases, abscess"),
                    dense: true,
                  ),
                  ListTile(
                    leading: Text("7.", style: TextStyle(fontWeight: FontWeight.bold)),
                    title: Text("Cerebellar lesion, brainstem lesion"),
                    dense: true,
                  ),
                  ListTile(
                    leading: Text("8.", style: TextStyle(fontWeight: FontWeight.bold)),
                    title: Text("Congenital abnormalities"),
                    dense: true,
                  ),
                  ListTile(
                    leading: Text("9.", style: TextStyle(fontWeight: FontWeight.bold)),
                    title: Text("Post-operative follow-up"),
                    dense: true,
                  ),
                  ListTile(
                    leading: Text("10.", style: TextStyle(fontWeight: FontWeight.bold)),
                    title: Text("Vascular pathologies"),
                    dense: true,
                  ),
                  ListTile(
                    leading: Text("11.", style: TextStyle(fontWeight: FontWeight.bold)),
                    title: Text("Headaches"),
                    dense: true,
                  ),
                  ListTile(
                    leading: Text("12.", style: TextStyle(fontWeight: FontWeight.bold)),
                    title: Text("Haemorrhage"),
                    dense: true,
                  ),
                  ListTile(
                    leading: Text("13.", style: TextStyle(fontWeight: FontWeight.bold)),
                    title: Text("Trauma"),
                    dense: true,
                  ),
                  ListTile(
                    leading: Text("14.", style: TextStyle(fontWeight: FontWeight.bold)),
                    title: Text("Ataxia"),
                    dense: true,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
} */

 // page 3
 import 'package:flutter/material.dart';

 void main() {
   runApp(const MyApp());
 }

 class MyApp extends StatelessWidget {
   const MyApp({super.key});

   @override
   Widget build(BuildContext context) {
     return Scaffold(
       body: Column(
         children: [
           Container(
             color: const Color(0xFFE53935),
             padding: const EdgeInsets.only(top: 40, bottom: 12, left: 16, right: 16),
             child: Row(
               children: [
                 const Icon(Icons.arrow_back, color: Colors.white),
                 const SizedBox(width: 16),
                 const Text(
                   "Mitral regurgitation",
                   style: TextStyle(
                     color: Colors.white,
                     fontSize: 20,
                     fontWeight: FontWeight.w600,
                   ),
                 ),
               ],
             ),
           ),
           Expanded(
             child: SingleChildScrollView(
               padding: const EdgeInsets.all(16),
               child: Column(
                 crossAxisAlignment: CrossAxisAlignment.start,
                 children: [
                   const Text(
                     "CMR accurately quantifies MR as the difference between left ventricular stroke volume and forward stroke volume using steady-state free precession and phase contrast imaging. This method is reproducible and can quantify MR in patients without regard to regurgitant jet morphology, such as patients with multiple and eccentric jets. It can also quantify regurgitant volume in patients with multiple valve lesions and concomitant intracardiac shunts without the use of intravenous contrast [2].",
                     style: TextStyle(fontSize: 15, height: 1.5),
                   ),
                   const SizedBox(height: 16),
                   const Text(
                     "Studies have shown that CMR quantification of MR was associated with the development of symptoms or other indications for surgery and showed better discriminatory ability than the reference-standard CMR-derived ventricular volumes [3]. This suggests that CMR may be able to identify appropriate patients for early surgery, although the clinical benefits of early surgery require confirmation in a clinical trial.",
                     style: TextStyle(fontSize: 15, height: 1.5),
                   ),
                   const SizedBox(height: 24),
                   const Text(
                     "Recommended grading of MR by CMR assessment [1]",
                     style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                   ),
                   const SizedBox(height: 12),
                   Table(
                     border: TableBorder.all(color: Colors.grey.shade400),
                     columnWidths: const {
                       0: FlexColumnWidth(1.8),
                       1: FlexColumnWidth(1),
                       2: FlexColumnWidth(1),
                       3: FlexColumnWidth(1),
                     },
                     children: [
                       TableRow(
                         decoration: const BoxDecoration(color: Color(0xFFE53935)),
                         children: [
                           const Padding(
                             padding: EdgeInsets.all(8),
                             child: Text("Type of MR", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                           ),
                           const Padding(
                             padding: EdgeInsets.all(8),
                             child: Text("Mild", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                           ),
                           const Padding(
                             padding: EdgeInsets.all(8),
                             child: Text("Moderate", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                           ),
                           const Padding(
                             padding: EdgeInsets.all(8),
                             child: Text("Severe", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                           ),
                         ],
                       ),
                       TableRow(
                         children: [
                           const Padding(
                             padding: EdgeInsets.all(8),
                             child: Text("1*"),
                           ),
                           const Padding(
                             padding: EdgeInsets.all(8),
                             child: Text("<20%"),
                           ),
                           const Padding(
                             padding: EdgeInsets.all(8),
                             child: Text("20-39%"),
                           ),
                           const Padding(
                             padding: EdgeInsets.all(8),
                             child: Text(">40%"),
                           ),
                         ],
                       ),
                       TableRow(
                         children: [
                           const Padding(
                             padding: EdgeInsets.all(8),
                             child: Text("1#"),
                           ),
                           const Padding(
                             padding: EdgeInsets.all(8),
                             child: Text(""),
                           ),
                           const Padding(
                             padding: EdgeInsets.all(8),
                             child: Text(""),
                           ),
                           const Padding(
                             padding: EdgeInsets.all(8),
                             child: Text(">55 ml"),
                           ),
                         ],
                       ),
                       TableRow(
                         children: [
                           const Padding(
                             padding: EdgeInsets.all(8),
                             child: Text("2#"),
                           ),
                           const Padding(
                             padding: EdgeInsets.all(8),
                             child: Text("<30 ml"),
                           ),
                           const Padding(
                             padding: EdgeInsets.all(8),
                             child: Text("30-60 ml"),
                           ),
                           const Padding(
                             padding: EdgeInsets.all(8),
                             child: Text(">60 ml"),
                           ),
                         ],
                       ),
                     ],
                   ),
                   const SizedBox(height: 12),
                   const Text(
                     "1: Primary MR\n2: Secondary MR\n*: Regurgitant fraction",
                     style: TextStyle(fontSize: 14, height: 1.6),
                   ),
                 ],
               ),
             ),
           ),
         ],
       ),
     );
   }
 }

