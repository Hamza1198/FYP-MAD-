/*
// page 1
import 'package:flutter/material.dart';
void main() {
  runApp(const MyApp());
}
class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: SplashScreen(),
    );
  }
}
class SplashScreen extends StatelessWidget {
  const SplashScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFF1E3A8A), Color(0xFF1E40AF)],
          ),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.network(
              'https://www.nobleimaginganddiagnostics.com/wp-content/uploads/2025/04/MRI-Cardiac.jpg',
              height: 120,
            ),
            const SizedBox(height: 20),
            const Icon(Icons.medical_services, color: Colors.white, size: 50),
            const SizedBox(height: 20),
            const Text(
              'MRI MASTER',
              style: TextStyle(color: Colors.white, fontSize: 30),
            ),
            const SizedBox(height: 30),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 30),
              child: TextField(
                decoration: InputDecoration(
                  filled: true,
                  fillColor: Colors.white,
                  hintText: "Enter Username",
                  prefixIcon: const Icon(Icons.person),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
// page 2
import 'package:flutter/material.dart';
void main() {
  runApp(const MyApp());
}
class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: IndicationsScreen(),
    );
  }
}
class IndicationsScreen extends StatelessWidget {
  const IndicationsScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("PLANNING > HEART"),
        actions: const [Icon(Icons.home)],
      ),
      body: Column(
        children: [
          Image.network(
            'https://www.nm.org/-/media/northwestern/healthbeat/images/healthy-tips/what-is-cardiac-mri_pv.jpg?la=en&h=450&w=800&hash=78D34C6B4CD996AF5AFDA75DF06AFD72',
            height: 250,
            width: double.infinity,
            fit: BoxFit.cover,
            loadingBuilder: (context, child, progress) {
              if (progress == null) return child;
              return const Padding(
                padding: EdgeInsets.all(20),
                child: CircularProgressIndicator(),
              );
            },
            errorBuilder: (context, error, stackTrace) {
              return const Padding(
                padding: EdgeInsets.all(20),
                child: Icon(Icons.broken_image, size: 50),
              );
            },
          ),
          const SizedBox(height: 10),
          Padding(
            padding: const EdgeInsets.all(12),
            child: TextField(
              decoration: InputDecoration(
                hintText: "Search Indications",
                prefixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
            ),
          ),
          Expanded(
            child: ListView(
              children: const [
                ListTile(
                  leading: Icon(Icons.warning, color: Colors.red),
                  title: Text("Transient ischaemic attack"),
                ),
                ListTile(
                  leading: Icon(Icons.coronavirus, color: Colors.orange),
                  title: Text("Infection, meningitis"),
                ),
                ListTile(
                  leading: Icon(Icons.psychology, color: Colors.blue),
                  title: Text("Cognitive decline"),
                ),
                ListTile(
                  leading: Icon(Icons.flash_on, color: Colors.purple),
                  title: Text("Seizures, epilepsy"),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
} */

// page 3
import 'package:flutter/material.dart';
void main() {
  runApp(const MyApp());
}
class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: MRScreen(),
    );
  }
}
class MRScreen extends StatelessWidget {
  const MRScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Mitral Regurgitation"),
        leading: const Icon(Icons.arrow_back),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Image.network(
              'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTzIK8oQ4_IJ5CGuT3s71F3ROhkRoo_MnyxgA&s',
              height: 300,
              width: double.infinity,
              fit: BoxFit.cover,
              loadingBuilder: (context, child, progress) {
                if (progress == null) return child;
                return const Padding(
                  padding: EdgeInsets.all(20),
                  child: CircularProgressIndicator(),
                );
              },
              errorBuilder: (context, error, stackTrace) {
                return const Padding(
                  padding: EdgeInsets.all(20),
                  child: Icon(Icons.broken_image, size: 50),
                );
              },
            ),
            const SizedBox(height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: const [
                Icon(Icons.favorite, color: Colors.red),
                SizedBox(width: 10),
                Icon(Icons.monitor_heart, color: Colors.blue),
              ],
            ),
            const SizedBox(height: 20),
            TextField(
              decoration: InputDecoration(
                labelText: "Add Notes",
                prefixIcon: const Icon(Icons.note),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              maxLines: 3,
            ),
            const SizedBox(height: 20),
            const Text(
              "Cardiac MRI (CMR) is used to evaluate mitral regurgitation by measuring regurgitant volume and fraction. It provides accurate and reproducible assessment of heart function and valve abnormalities.",
              style: TextStyle(fontSize: 15),
            ),
          ],
        ),
      ),
    );
  }
}