import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'AI MRI App',
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF0D1B2A),
      ),
      home: Home(),
    );
  }
}

class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    _tabController.addListener(() {
      if (_tabController.indexIsChanging) {
        print("Tab changed to: ${_tabController.index}");
      }
    });
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  // ================= DRAWER =================
  Drawer buildDrawer() {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          UserAccountsDrawerHeader(
            accountName: Text("Dr. User"),
            accountEmail: Text("doctor@hospital.com"),
            currentAccountPicture: CircleAvatar(
              child: Icon(Icons.person),
            ),
            decoration: BoxDecoration(
              color: Color(0xFF1B263B),
            ),
          ),
          ListTile(
            leading: Icon(Icons.dashboard),
            title: Text("Dashboard"),
            onTap: () {
              Navigator.pop(context);
            },
          ),
          ListTile(
            leading: Icon(Icons.upload_file),
            title: Text("Upload MRI"),
            onTap: () {
              Navigator.pop(context);
            },
          ),
          ListTile(
            leading: Icon(Icons.history),
            title: Text("History"),
            onTap: () {
              Navigator.pop(context);
            },
          ),
          Divider(),
          ListTile(
            leading: Icon(Icons.settings),
            title: Text("Settings"),
            onTap: () {
              Navigator.pop(context);
            },
          ),
        ],
      ),
    );
  }

  // ================= TABS =================

  Widget mriScanTab() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.upload_file, size: 100, color: Colors.blueAccent),
          SizedBox(height: 20),
          Text(
            "Upload MRI Scan",
            style: TextStyle(fontSize: 20),
          ),
        ],
      ),
    );
  }

  Widget segmentationTab() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.auto_graph, size: 100, color: Colors.green),
          SizedBox(height: 20),
          Text(
            "AI Tumor Segmentation",
            style: TextStyle(fontSize: 20),
          ),
        ],
      ),
    );
  }

  Widget reportsTab() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.insert_chart, size: 100, color: Colors.orange),
          SizedBox(height: 20),
          Text(
            "Diagnostic Reports",
            style: TextStyle(fontSize: 20),
          ),
        ],
      ),
    );
  }

  // ================= UI =================

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("AI MRI Dashboard"),
        backgroundColor: Color(0xFF1B263B),
      ),
      drawer: buildDrawer(),
      body: TabBarView(
        controller: _tabController,
        children: [
          mriScanTab(),
          segmentationTab(),
          reportsTab(),
        ],
      ),
      bottomNavigationBar: TabBar(
        controller: _tabController,
        labelColor: Colors.white,
        unselectedLabelColor: Colors.grey,
        indicatorColor: Colors.blueAccent,
        tabs: [
          Tab(icon: Icon(Icons.medical_services), text: "Scan"),
          Tab(icon: Icon(Icons.analytics), text: "AI Result"),
          Tab(icon: Icon(Icons.description), text: "Reports"),
        ],
      ),
    );
  }
}
