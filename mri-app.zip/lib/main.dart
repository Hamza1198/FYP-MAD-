import 'package:flutter/material.dart';

void main() {
  runApp(MRIApp());
}

class MRIApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'MRI AI Segmentation',
      home: MRIScreen(),
    );
  }
}

class MRIScreen extends StatefulWidget {
  @override
  _MRIScreenState createState() => _MRIScreenState();
}

class _MRIScreenState extends State<MRIScreen> with TickerProviderStateMixin {
  // ---------------- AnimatedContainer ----------------
  double _width = 150;

  void _expandScan() {
    setState(() {
      _width = (_width >= 300) ? 150 : _width + 50;
    });
  }

  // ---------------- CrossFade ----------------
  bool _showTumor = false;

  void _toggleScan() {
    setState(() {
      _showTumor = !_showTumor;
    });
  }

  // ---------------- Opacity ----------------
  double _opacity = 1.0;

  void _fadeResult() {
    setState(() {
      _opacity = _opacity == 1.0 ? 0.2 : 1.0;
    });
  }

  // ---------------- Animation Controller ----------------
  late AnimationController _controller;
  late Animation<double> _moveUp;
  late Animation<double> _sizeGrow;

  // ---------------- Staggered ----------------
  late Animation<double> _staggerMove;
  late Animation<double> _staggerSize;

  @override
  void initState() {
    super.initState();

    _controller = AnimationController(
      vsync: this,
      duration: Duration(seconds: 3),
    );

    _moveUp = Tween(begin: 300.0, end: 50.0).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeOut),
    );

    _sizeGrow = Tween(begin: 80.0, end: 150.0).animate(
      CurvedAnimation(parent: _controller, curve: Curves.elasticOut),
    );

    // Staggered animation
    _staggerMove = Tween(begin: 300.0, end: 100.0).animate(
      CurvedAnimation(parent: _controller, curve: Interval(0.0, 0.5)),
    );

    _staggerSize = Tween(begin: 80.0, end: 160.0).animate(
      CurvedAnimation(parent: _controller, curve: Interval(0.5, 1.0)),
    );
  }

  void _startDetection() {
    if (_controller.isCompleted) {
      _controller.reverse();
    } else {
      _controller.forward();
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  // ---------------- UI ----------------

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("MRI AI Segmentation")),
      body: SingleChildScrollView(
        child: Column(
          children: [
            // ---------------- AnimatedContainer ----------------
            SizedBox(height: 20),
            Text("MRI Scan Box (Tap to Expand)"),
            GestureDetector(
              onTap: _expandScan,
              child: AnimatedContainer(
                duration: Duration(milliseconds: 500),
                curve: Curves.easeInOut,
                width: _width,
                height: 150,
                color: Colors.blueAccent,
                alignment: Alignment.center,
                child: Text("MRI Scan"),
              ),
            ),

            // ---------------- CrossFade ----------------
            SizedBox(height: 30),
            Text("Normal vs Tumor Detection"),
            GestureDetector(
              onTap: _toggleScan,
              child: AnimatedCrossFade(
                duration: Duration(milliseconds: 500),
                firstChild: Container(
                  width: 150,
                  height: 150,
                  color: Colors.green,
                  child: Center(child: Text("Normal")),
                ),
                secondChild: Container(
                  width: 200,
                  height: 200,
                  color: Colors.red,
                  child: Center(child: Text("Tumor Detected")),
                ),
                crossFadeState: _showTumor
                    ? CrossFadeState.showSecond
                    : CrossFadeState.showFirst,
              ),
            ),

            // ---------------- Opacity ----------------
            SizedBox(height: 30),
            Text("Fade Result"),
            GestureDetector(
              onTap: _fadeResult,
              child: AnimatedOpacity(
                duration: Duration(milliseconds: 500),
                opacity: _opacity,
                child: Container(
                  width: 150,
                  height: 150,
                  color: Colors.orange,
                  child: Center(child: Text("Result")),
                ),
              ),
            ),

            // ---------------- Animation Controller ----------------
            SizedBox(height: 40),
            Text("Tumor Detection Animation"),
            GestureDetector(
              onTap: _startDetection,
              child: AnimatedBuilder(
                animation: _controller,
                builder: (context, child) {
                  return Positioned(
                    top: _moveUp.value,
                    child: Container(
                      width: _sizeGrow.value,
                      height: _sizeGrow.value,
                      decoration: BoxDecoration(
                        color: Colors.purple,
                        shape: BoxShape.circle,
                      ),
                    ),
                  );
                },
              ),
            ),

            SizedBox(height: 300),

            // ---------------- Staggered ----------------
            Text("Staggered Diagnosis Animation"),
            GestureDetector(
              onTap: _startDetection,
              child: AnimatedBuilder(
                animation: _controller,
                builder: (context, child) {
                  return Container(
                    margin: EdgeInsets.only(top: _staggerMove.value),
                    width: _staggerSize.value,
                    height: _staggerSize.value,
                    color: Colors.teal,
                  );
                },
              ),
            ),

            SizedBox(height: 50),
          ],
        ),
      ),
    );
  }
}
